﻿using Microsoft.AspNetCore.Mvc;
using secretSanta.Models;
using secretSanta.Services;


namespace secretSanta.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SecretSantaController : ControllerBase
    {
        private readonly ISecretSantaService _SecretSantaService;

        public SecretSantaController(ISecretSantaService SecretSantaService)
        {
            _SecretSantaService = SecretSantaService;

        }
       

        [HttpPost]
        public ActionResult Post(List<playerDetails> playerList)
        {
           

           var result =  _SecretSantaService.Randomizer(playerList);
            _SecretSantaService.sendEmailToList(playerList, result);

            return Ok(result);
            

        }

       
    }
}
